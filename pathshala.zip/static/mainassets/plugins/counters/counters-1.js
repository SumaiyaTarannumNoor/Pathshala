$( function() {
	$('.counter').countUp();
});